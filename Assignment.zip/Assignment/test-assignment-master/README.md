## Basic Overview

This is a simple shopping cart prototype.

## Build/Run

#### Requirements

- Node.js - Currently only working with Node.js 11.* versions
- NPM
- Follow the instructions mentioned here to install node-gyp
    https://github.com/nodejs/node-gyp

```javascript

/* First, Install the needed packages */
npm install

/* If the project does not compile */
- Install Python 3.*
- If on Windows, add it to the path: setx PYTHON "%USERPROFILE%\.windows-build-tools\python27\python.exe"
- npm install

/* Then start both Node and React */
npm start

```
## Tests:
1. Validate whether the products can be sorted Lowest to Highest and assert the price of first product is kr 9.000
2. Validate whether the products can be sorted Highest to Lowest and assert the price of first product is kr 134.900
3. Validate whether the products can be filtered by selecting Size S and assert the combined price of items is kr 33.400
4. Select only the products which have installments and assert the total number of products is 15
5. Without selecting any product, go to cart and click on Checkout. Assert the text in Alert box is "Add some product in the cart!"
6. Select "Sphynx Tie Dye Wine T-Shirt", go to checkout and handel the alerts


## Methodology:
1. Download this project
2. Build and run it locally
3. Automate the above mentioned test cases using any framework/tool

Best of luck!!

### Copyright and license

The MIT License (MIT). Please see License File for more information.

<br/>
<br/>

