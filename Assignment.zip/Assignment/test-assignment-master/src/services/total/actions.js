import { UPDATE_CART } from './actionTypes';

export const updateCart = cartProducts => dispatch => {
  let productQuantity = cartProducts.reduce((sum, p) => {
    sum += p.quantity;
    return sum;
  }, 0);

  let totalPrice = cartProducts.reduce((sum, p) => {
    if(p.isFreeShipping){sum += p.price * p.quantity;}
    else{sum += (p.deliveryCharges + (p.price * p.quantity));}
    return sum;
  }, 0);

  let delivery = cartProducts.reduce((sum, p) => {
    if(!p.isFreeShipping){sum += p.deliveryCharges ;}

    return sum;
  }, 0);

  let installments = cartProducts.reduce((greater, p) => {
    greater = p.installments > greater ? p.installments : greater;
    return greater;
  }, 0);

  let cartTotal = {
    productQuantity,
    installments,
    totalPrice,
    delivery,
    currencyId: 'USD',
    currencyFormat: '$'
  };

  dispatch({
    type: UPDATE_CART,
    payload: cartTotal
  });
};
